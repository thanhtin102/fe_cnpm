
function ErrorPage() {
    
    return ( 
        <div className="w-screen h-screen z-1000">
            <img className="object-cover" src="https://github.com/vikas-kukreti/404-error-page/blob/master/res/screenshot.png?raw=true" alt="error" />
        </div>
     );
}

export default ErrorPage;