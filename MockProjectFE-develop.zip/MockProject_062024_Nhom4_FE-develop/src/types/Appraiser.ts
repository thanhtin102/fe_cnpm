export interface Appraiser {
    id: string;
    nameOrganization: string;
    address: string;
    email: string;
    phone: string;
}